#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 12:52:53 2024

@author: isaacfoster
"""
#%% Initialize
import numpy as np

#### Set Printing
np.set_printoptions(suppress=True, precision=6)



    