#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 15 16:13:10 2024

@author: isaacfoster
"""

#%% Initialize
import numpy as np


#%% Functions