#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 13:17:47 2024

@author: isaacfoster
"""

class bolt():
    def __init__(self,material):
        self.material = material

class surface():
    pass

class solid():
    pass

class cylinder():
    pass

class sphere():
    pass

class heater():
    pass

class washer():
    pass

class isolator():
    pass